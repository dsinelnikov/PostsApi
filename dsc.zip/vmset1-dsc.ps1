Configuration Main
{

Param ( [string] $nodeName )

Node $nodeName
  {
	Script InstallNetCore
	{
		TestScript={
			return $false;
		}
		SetScript = {
			#Write-Host "About to clear .NET cache from my profile..."
			$dotnetProfileFolder = "C:\Users\%USERNAME%\.dotnet"
			Remove-Item $dotnetProfileFolder\* -recurse

			# https://jeremylindsayni.wordpress.com/2016/05/24/fixing-rogue-behaviour-in-nuget-by-clearing-the-caches/
			#Write-Host "About to clear Nuget Cache..."
			nuget locals all -clear

			# https://blog.jourdant.me/post/3-ways-to-download-files-with-powershell
			#Write-Host "About to delete existing .NET Core binaries..."
			$dotNetSdkFolder = "C:\Program Files\dotnet"
			Remove-Item $dotNetSdkFolder\* -recurse

			#Write-Host "About to download latest .NET Core 2 binaries..."
			$url = "https://dotnetcli.blob.core.windows.net/dotnet/Sdk/master/dotnet-dev-win-x64.latest.zip"
			$output = "$dotNetSdkFolder\dotnet-dev-win-x64.latest.zip"

			Import-Module BitsTransfer
			Start-BitsTransfer -Source $url -Destination $output

			# https://www.howtogeek.com/tips/how-to-extract-zip-files-using-powershell/
			#Write-Host "About to unzip latest .NET Core 2 binaries..."
			$shell = new-object -com shell.application
			$zip = $shell.NameSpace($output)
			foreach($item in $zip.items())
			{
			 $shell.Namespace($dotNetSdkFolder).copyhere($item)
			}

			#Write-Host "Done - dotnet version installed is:"
			dotnet --version
		}		
	}

   <# This commented section represents an example configuration that can be updated as required.
    WindowsFeature WebServerRole
    {
      Name = "Web-Server"
      Ensure = "Present"
    }
    WindowsFeature WebManagementConsole
    {
      Name = "Web-Mgmt-Console"
      Ensure = "Present"
    }
    WindowsFeature WebManagementService
    {
      Name = "Web-Mgmt-Service"
      Ensure = "Present"
    }
    WindowsFeature ASPNet45
    {
      Name = "Web-Asp-Net45"
      Ensure = "Present"
    }
    WindowsFeature HTTPRedirection
    {
      Name = "Web-Http-Redirect"
      Ensure = "Present"
    }
    WindowsFeature CustomLogging
    {
      Name = "Web-Custom-Logging"
      Ensure = "Present"
    }
    WindowsFeature LogginTools
    {
      Name = "Web-Log-Libraries"
      Ensure = "Present"
    }
    WindowsFeature RequestMonitor
    {
      Name = "Web-Request-Monitor"
      Ensure = "Present"
    }
    WindowsFeature Tracing
    {
      Name = "Web-Http-Tracing"
      Ensure = "Present"
    }
    WindowsFeature BasicAuthentication
    {
      Name = "Web-Basic-Auth"
      Ensure = "Present"
    }
    WindowsFeature WindowsAuthentication
    {
      Name = "Web-Windows-Auth"
      Ensure = "Present"
    }
    WindowsFeature ApplicationInitialization
    {
      Name = "Web-AppInit"
      Ensure = "Present"
    }
    Script DownloadWebDeploy
    {
        TestScript = {
            Test-Path "C:\WindowsAzure\WebDeploy_amd64_en-US.msi"
        }
        SetScript ={
            $source = "https://download.microsoft.com/download/0/1/D/01DC28EA-638C-4A22-A57B-4CEF97755C6C/WebDeploy_amd64_en-US.msi"
            $dest = "C:\WindowsAzure\WebDeploy_amd64_en-US.msi"
            Invoke-WebRequest $source -OutFile $dest
        }
        GetScript = {@{Result = "DownloadWebDeploy"}}
        DependsOn = "[WindowsFeature]WebServerRole"
    }
    Package InstallWebDeploy
    {
        Ensure = "Present"  
        Path  = "C:\WindowsAzure\WebDeploy_amd64_en-US.msi"
        Name = "Microsoft Web Deploy 3.6"
        ProductId = "{ED4CC1E5-043E-4157-8452-B5E533FE2BA1}"
        Arguments = "ADDLOCAL=ALL"
        DependsOn = "[Script]DownloadWebDeploy"
    }
    Service StartWebDeploy
    {                    
        Name = "WMSVC"
        StartupType = "Automatic"
        State = "Running"
        DependsOn = "[Package]InstallWebDeploy"
    } #>
  }
}